import WhatsInside from '../WhatsInside';

export default function WhatsInsideExample() {
  return <div className="bg-black"><WhatsInside /></div>;
}
