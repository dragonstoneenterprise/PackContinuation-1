import { useState } from 'react';
import CartDrawer, { CartItem } from '../CartDrawer';
import { Button } from '@/components/ui/button';
import homeOfficeImage from "@assets/generated_images/Home_Office_Power_Kit_86e8fe5e.png";
import gamerPackImage from "@assets/generated_images/4K_Gamer_Pack_8ad63812.png";

export default function CartDrawerExample() {
  const [isOpen, setIsOpen] = useState(true);
  const [items, setItems] = useState<CartItem[]>([
    {
      id: '1',
      name: 'Home Office Power Kit',
      description: 'For remote work efficiency',
      image: homeOfficeImage,
      price: 79,
      originalPrice: 118,
      category: 'Productivity',
      quantity: 2
    },
    {
      id: '2',
      name: '4K Gamer Pack',
      description: 'For console & PC gamers',
      image: gamerPackImage,
      price: 89,
      originalPrice: 135,
      category: 'Gaming',
      quantity: 1
    }
  ]);

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      setItems(items.filter(item => item.id !== productId));
    } else {
      setItems(items.map(item => 
        item.id === productId ? { ...item, quantity } : item
      ));
    }
  };

  const handleRemoveItem = (productId: string) => {
    setItems(items.filter(item => item.id !== productId));
  };

  return (
    <div>
      <Button onClick={() => setIsOpen(true)}>Open Cart</Button>
      <CartDrawer 
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        items={items}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={() => console.log('Checkout clicked')}
      />
    </div>
  );
}
