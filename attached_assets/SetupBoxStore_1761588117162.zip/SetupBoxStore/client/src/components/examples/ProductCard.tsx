import ProductCard from '../ProductCard';
import homeOfficeImage from "@assets/generated_images/Home_Office_Power_Kit_86e8fe5e.png";

export default function ProductCardExample() {
  const product = {
    id: '1',
    name: 'Home Office Power Kit',
    description: 'For remote work efficiency',
    image: homeOfficeImage,
    price: 79,
    originalPrice: 118,
    category: 'Productivity'
  };

  return (
    <div className="max-w-sm">
      <ProductCard 
        product={product}
        onAddToCart={(p) => console.log('Add to cart:', p.name)}
        onViewDetails={(p) => console.log('View details:', p.name)}
      />
    </div>
  );
}
