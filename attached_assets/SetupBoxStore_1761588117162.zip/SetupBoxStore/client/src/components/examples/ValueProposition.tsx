import ValueProposition from '../ValueProposition';

export default function ValuePropositionExample() {
  return <ValueProposition />;
}
