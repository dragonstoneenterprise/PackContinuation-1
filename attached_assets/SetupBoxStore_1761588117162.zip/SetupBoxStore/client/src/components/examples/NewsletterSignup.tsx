import NewsletterSignup from '../NewsletterSignup';

export default function NewsletterSignupExample() {
  return <NewsletterSignup />;
}
