import FeaturedBundles from '../FeaturedBundles';
import homeOfficeImage from "@assets/generated_images/Home_Office_Power_Kit_86e8fe5e.png";
import gamerPackImage from "@assets/generated_images/4K_Gamer_Pack_8ad63812.png";
import streamingImage from "@assets/generated_images/Streaming_Setup_Pro_e346e7da.png";
import deskBundleImage from "@assets/generated_images/Studio_Clean_Desk_Bundle_d6f13007.png";

export default function FeaturedBundlesExample() {
  const products = [
    {
      id: '1',
      name: 'Home Office Power Kit',
      description: 'For remote work efficiency',
      image: homeOfficeImage,
      price: 79,
      originalPrice: 118,
      category: 'Productivity'
    },
    {
      id: '2',
      name: '4K Gamer Pack',
      description: 'For console & PC gamers',
      image: gamerPackImage,
      price: 89,
      originalPrice: 135,
      category: 'Gaming'
    },
    {
      id: '3',
      name: 'Streaming Setup Pro',
      description: 'For creators & streamers',
      image: streamingImage,
      price: 99,
      originalPrice: 145,
      category: 'Creator'
    },
    {
      id: '4',
      name: 'Studio Clean Desk Bundle',
      description: 'For minimalist workspaces',
      image: deskBundleImage,
      price: 69,
      originalPrice: 98,
      category: 'Organization'
    }
  ];

  return (
    <FeaturedBundles 
      products={products}
      onAddToCart={(p) => console.log('Add to cart:', p.name)}
      onViewDetails={(p) => console.log('View details:', p.name)}
    />
  );
}
