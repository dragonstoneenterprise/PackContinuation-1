import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export interface Product {
  id: string;
  name: string;
  description: string;
  image: string;
  price: number;
  originalPrice?: number;
  category: string;
}

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
  onViewDetails?: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onViewDetails }: ProductCardProps) {
  const savings = product.originalPrice ? product.originalPrice - product.price : 0;
  const savingsPercent = product.originalPrice 
    ? Math.round((savings / product.originalPrice) * 100) 
    : 0;

  return (
    <div className="group">
      <div 
        className="aspect-square bg-gradient-to-br from-zinc-900 to-black rounded-lg p-8 flex items-center justify-center mb-4 overflow-hidden cursor-pointer"
        onClick={() => onViewDetails?.(product)}
      >
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-contain transition-transform group-hover:scale-105"
          data-testid={`img-product-${product.id}`}
        />
      </div>
      <div className="text-center space-y-3">
        <div>
          <h3 className="font-semibold text-lg mb-1 text-white" data-testid={`text-name-${product.id}`}>
            {product.name}
          </h3>
          <p className="text-sm text-white/50" data-testid={`text-description-${product.id}`}>
            {product.description}
          </p>
        </div>
        <div className="flex items-baseline justify-center gap-2">
          <span className="text-xl font-bold text-white" data-testid={`text-price-${product.id}`}>
            ${product.price}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-white/40 line-through">
              ${product.originalPrice}
            </span>
          )}
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline"
            className="flex-1 border-white/20 text-white hover:bg-white/10" 
            onClick={(e) => {
              e.stopPropagation();
              onViewDetails?.(product);
            }}
            data-testid={`button-learn-more-${product.id}`}
          >
            Learn More
          </Button>
          <Button 
            className="flex-1 bg-white text-black hover:bg-white/90" 
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart?.(product);
            }}
            data-testid={`button-buy-${product.id}`}
          >
            Buy
          </Button>
        </div>
      </div>
    </div>
  );
}
