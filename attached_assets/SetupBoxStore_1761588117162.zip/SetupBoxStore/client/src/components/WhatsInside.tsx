import { Monitor, Zap, Cable, Package, FileText } from "lucide-react";

const items = [
  { icon: Monitor, label: "Mount" },
  { icon: Zap, label: "Power" },
  { icon: Cable, label: "Cables" },
  { icon: Package, label: "Organizers" },
  { icon: FileText, label: "Guide" }
];

export default function WhatsInside() {
  return (
    <section className="py-24 bg-black">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-bold text-center text-white mb-16">
          What's Inside a Kit?
        </h2>
        
        <div className="flex flex-wrap justify-center gap-12 md:gap-16 max-w-4xl mx-auto mb-12">
          {items.map((item, index) => {
            const Icon = item.icon;
            return (
              <div key={index} className="flex flex-col items-center gap-4" data-testid={`kit-item-${index}`}>
                <div className="w-16 h-16 flex items-center justify-center">
                  <Icon className="w-12 h-12 text-white/80 stroke-[1.5]" />
                </div>
                <span className="text-white/70 text-sm font-medium">{item.label}</span>
              </div>
            );
          })}
        </div>
        
        <p className="text-center text-white/60 max-w-2xl mx-auto text-lg">
          We hand-pick proven components, combine them into one box, and give you simple setup instructions.
        </p>
      </div>
    </section>
  );
}
