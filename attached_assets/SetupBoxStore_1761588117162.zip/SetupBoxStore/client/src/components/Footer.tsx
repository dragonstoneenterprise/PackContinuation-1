import { Shield, RefreshCw, CreditCard } from "lucide-react";

const trustBadges = [
  { icon: CreditCard, text: "Secure Payment" },
  { icon: RefreshCw, text: "Easy Returns" },
  { icon: Shield, text: "U.S. Warranty" }
];

const links = [
  { label: "About", href: "#" },
  { label: "Contact", href: "#" },
  { label: "Privacy", href: "#" },
  { label: "Terms", href: "#" }
];

export default function Footer() {
  return (
    <footer className="bg-black border-t border-white/10">
      <div className="container mx-auto px-6 py-12">
        <div className="flex flex-wrap justify-center gap-8 mb-8">
          {trustBadges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <div key={index} className="flex items-center gap-2" data-testid={`trust-badge-${index}`}>
                <Icon className="w-5 h-5 text-white/60" />
                <span className="text-sm font-medium text-white/60">{badge.text}</span>
              </div>
            );
          })}
        </div>
        
        <div className="flex flex-wrap justify-center gap-6 mb-8">
          {links.map((link, index) => (
            <a
              key={index}
              href={link.href}
              className="text-sm text-white/40 hover:text-white/70 transition-colors"
              data-testid={`link-${link.label.toLowerCase()}`}
            >
              {link.label}
            </a>
          ))}
        </div>
        
        <div className="text-center text-sm text-white/40">
          <p className="font-medium mb-1">
            Haven by Dragonstone Enterprises LLC
          </p>
          <p>Crafted for Efficiency</p>
        </div>
      </div>
    </footer>
  );
}
