import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

export default function NewsletterSignup() {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    
    console.log('Newsletter signup:', email);
    toast({
      title: "Thanks for subscribing!",
      description: "You'll receive setup tips & exclusive deals soon.",
    });
    setEmail("");
  };

  return (
    <section className="py-16 bg-primary/5">
      <div className="container mx-auto px-6 max-w-2xl text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-4">
          Join Dragonstone Labs
        </h2>
        <p className="text-muted-foreground mb-6">
          Get setup tips & exclusive deals delivered to your inbox
        </p>
        <form onSubmit={handleSubmit} className="flex gap-3 max-w-md mx-auto">
          <Input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="flex-1"
            data-testid="input-newsletter-email"
          />
          <Button type="submit" data-testid="button-newsletter-submit">
            Subscribe
          </Button>
        </form>
      </div>
    </section>
  );
}
