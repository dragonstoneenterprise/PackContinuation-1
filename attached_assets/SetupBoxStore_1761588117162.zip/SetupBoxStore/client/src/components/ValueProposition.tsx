import { Check } from "lucide-react";

const features = [
  "Monoprice-grade quality",
  "Curated by setup experts",
  "Fast U.S. shipping",
  "1-year warranty"
];

export default function ValueProposition() {
  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          Everything You Need. Nothing You Don't.
        </h2>
        <div className="flex flex-wrap justify-center gap-6 mt-8 max-w-3xl mx-auto">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="flex items-center gap-2 text-lg"
              data-testid={`feature-${index}`}
            >
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Check className="w-4 h-4 text-primary" />
              </div>
              <span>{feature}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
