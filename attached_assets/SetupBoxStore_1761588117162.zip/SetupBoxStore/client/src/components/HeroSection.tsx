import { Button } from "@/components/ui/button";
import heroImage from "@assets/generated_images/Clean_workspace_hero_background_42c8ed10.png";

interface HeroSectionProps {
  onShopClick?: () => void;
}

export default function HeroSection({ onShopClick }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-black">
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-40"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 tracking-tight leading-tight">
          Chaos kills<br/>creativity.
        </h1>
      </div>
    </section>
  );
}
