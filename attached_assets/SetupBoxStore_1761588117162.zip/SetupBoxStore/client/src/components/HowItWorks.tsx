import { Package, Truck, Zap } from "lucide-react";

const steps = [
  {
    icon: Package,
    title: "Choose your setup",
    description: "Select the perfect bundle for your needs"
  },
  {
    icon: Truck,
    title: "Delivered ready to connect",
    description: "Fast shipping, everything included"
  },
  {
    icon: Zap,
    title: "Plug in. Power up. Done.",
    description: "Start using your tech immediately"
  }
];

export default function HowItWorks() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          How It Works
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="text-center" data-testid={`step-${index + 1}`}>
                <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
                  <Icon className="w-8 h-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-muted-foreground">{step.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
