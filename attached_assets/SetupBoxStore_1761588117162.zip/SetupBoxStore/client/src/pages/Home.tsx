import { useState } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import WhatsInside from "@/components/WhatsInside";
import FeaturedBundles from "@/components/FeaturedBundles";
import Footer from "@/components/Footer";
import CartDrawer, { CartItem } from "@/components/CartDrawer";
import { Product } from "@/components/ProductCard";
import { useToast } from "@/hooks/use-toast";

import homeOfficeImage from "@assets/generated_images/Home_Office_Power_Kit_86e8fe5e.png";
import gamerPackImage from "@assets/generated_images/4K_Gamer_Pack_8ad63812.png";
import streamingImage from "@assets/generated_images/Streaming_Setup_Pro_e346e7da.png";
import deskBundleImage from "@assets/generated_images/Studio_Clean_Desk_Bundle_d6f13007.png";

const products: Product[] = [
  {
    id: '1',
    name: 'Home Office Power Kit',
    description: 'For remote work efficiency',
    image: homeOfficeImage,
    price: 79,
    originalPrice: 118,
    category: 'Productivity'
  },
  {
    id: '2',
    name: '4K Gamer Pack',
    description: 'For console & PC gamers',
    image: gamerPackImage,
    price: 89,
    originalPrice: 135,
    category: 'Gaming'
  },
  {
    id: '3',
    name: 'Streaming Setup Pro',
    description: 'For creators & streamers',
    image: streamingImage,
    price: 99,
    originalPrice: 145,
    category: 'Creator'
  },
  {
    id: '4',
    name: 'Studio Clean Desk Bundle',
    description: 'For minimalist workspaces',
    image: deskBundleImage,
    price: 69,
    originalPrice: 98,
    category: 'Organization'
  }
];

export default function Home() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { toast } = useToast();

  const handleAddToCart = (product: Product) => {
    setCartItems(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    
    toast({
      title: "Added to cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity === 0) {
      setCartItems(prev => prev.filter(item => item.id !== productId));
    } else {
      setCartItems(prev =>
        prev.map(item =>
          item.id === productId ? { ...item, quantity } : item
        )
      );
    }
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== productId));
  };

  const handleCheckout = () => {
    console.log('Checkout:', cartItems);
    toast({
      title: "Checkout",
      description: "Checkout functionality coming soon!",
    });
  };

  const handleShopClick = () => {
    const bundlesSection = document.querySelector('[data-section="bundles"]');
    bundlesSection?.scrollIntoView({ behavior: 'smooth' });
  };

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-black">
      <Header cartItemCount={totalItems} onCartClick={() => setIsCartOpen(true)} />
      
      <main className="flex-1">
        <HeroSection onShopClick={handleShopClick} />
        <WhatsInside />
        
        <div data-section="bundles">
          <FeaturedBundles 
            products={products}
            onAddToCart={handleAddToCart}
            onViewDetails={(product) => console.log('View details:', product.name)}
          />
        </div>
      </main>
      
      <Footer />
      
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onCheckout={handleCheckout}
      />
    </div>
  );
}
