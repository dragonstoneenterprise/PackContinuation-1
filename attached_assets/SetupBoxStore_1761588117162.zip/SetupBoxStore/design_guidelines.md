# SetupBox™ by Dragonstone - Design Guidelines

## Brand Identity

**Brand Positioning**: Premium, minimalist electronics brand - Apple meets IKEA aesthetic. Confident, practical, no fluff. Focus on "the shortcut to a clean, functional setup."

**Color Palette**:
- Jet Black: #000000
- Graphite Gray: #222222  
- Pure White: #FFFFFF
- Dragonstone Red (accent): #C00000

**Typography**: Clean sans-serif - Inter or Helvetica Neue throughout

**Visual Aesthetic**: Premium tech gear in neat bundles, clean product shots, no clutter. White backgrounds with floating shadowed product images.

## Layout Structure

### Homepage Sections

**1. Hero Section**
- Headline: "The Smarter Way to Set Up."
- Subheadline: "Get the exact tech gear you need — curated bundles for work, play, and creativity."
- Primary CTA: "Shop Bundles" button in Dragonstone Red (#C00000)
- Background: Clean workspace with organized cables and lighting setup (hero image)
- Button should have blurred background when placed over image

**2. Featured Bundles Grid** (3-4 cards)
- "Home Office Power Kit" — For remote work efficiency
- "4K Gamer Pack" — For console & PC gamers  
- "Streaming Setup Pro" — For creators & streamers
- "Studio Clean Desk Bundle" — For minimalist workspaces
- White background cards with floating shadowed bundle images
- Hover effects on cards

**3. How It Works Section**
- Step 1: Choose your setup
- Step 2: Delivered ready to connect
- Step 3: Plug in. Power up. Done
- Minimal icons under each step

**4. Value Proposition Section**
- Headline: "Everything You Need. Nothing You Don't."
- Bullet points: "Monoprice-grade quality," "Curated by setup experts," "Fast U.S. shipping," "1-year warranty"

**5. Testimonials Carousel** (placeholder section)

**6. Newsletter Signup Banner**
- Copy: "Join Dragonstone Labs for setup tips & exclusive deals"
- Email input + submit button

### Product Page Template

**Layout**: White background with floating shadowed bundle images

**Headline Format**: "[Bundle Name] — Complete [Use Case] Kit"

**Content Sections**:
- "What's Inside" — Detailed item list
- "Perfect For" — Target audience description
- "Why It Works" — Short benefit-driven copy
- "Bundle Value" — Shows savings (e.g., "$118 value — you pay $79")
- "Add to Cart" button in Dragonstone Red (#C00000)

### Footer

**Trust Badges**: Secure Payment, Easy Returns, U.S. Warranty

**Footer Links**: About, Contact, Privacy, Terms

**Tagline**: "Dragonstone Enterprises LLC – Crafted for Efficiency"

## Design Principles

**Tone**: Direct, minimal, efficient. Focus on benefits, not specs. No technical jargon unless essential. Make customers feel like they're buying peace of mind, not cables.

**Spacing**: Use tailwind spacing units of 4, 6, 8, 12, 16 for consistent rhythm

**Component Style**: Clean, premium aesthetic with subtle shadows on product cards. Buttons with hover states. Minimal animations - only where they enhance usability.

## Images

**Hero Section**: Large hero image showing clean workspace with organized cables and lighting setup - professional product photography style

**Product Bundles**: Individual product bundle images on white backgrounds with soft shadows (floating effect)

**How It Works**: Minimal iconography for each of the 3 steps

All images should convey premium quality, organization, and efficiency - matching the brand's minimalist, functional aesthetic.